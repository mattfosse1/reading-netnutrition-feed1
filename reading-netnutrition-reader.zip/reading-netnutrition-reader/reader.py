#!/usr/bin/env python3
"""Export University of Reading's public CBORD NetNutrition menus.

This uses the same read-only session flow as a student browsing NetNutrition.
No accounts, passwords, private CBORD APIs, or bypasses of access control.
The Reading deployment has not yet been live-validated from this environment.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests
from bs4 import BeautifulSoup

BASE = "https://netmenu.cbord.co.uk/NetNutrition/UniversityofReading"
CALL_DELAY = float(os.getenv("CALL_DELAY_SECONDS", "0.25"))
TIMEOUT = 25
UA = "Mozilla/5.0 (compatible; ReadingPublicMenuReader/1.0; public, read-only menus)"
UNIT_RE = re.compile(r"unitsSelectUnit\(\s*['\"]?(\d+)")
MENU_RE = re.compile(r"menuListSelectMenu\(\s*['\"]?(\d+)")
DETAIL_RE = re.compile(r"getItemNutritionLabelOnClick\(\s*event\s*,\s*['\"]?(\d+)")
CATEGORY_RE = re.compile(r"toggleCourseItems\(\s*this\s*,\s*(\d+)")


def text(node: Any) -> str:
    return re.sub(r"\s+", " ", node.get_text(" ", strip=True) if node else "").strip()


def units(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    out, seen = [], set()
    for el in soup.select("[onclick*='unitsSelectUnit']"):
        m = UNIT_RE.search(el.get("onclick", ""))
        if m and m[1] not in seen:
            seen.add(m[1])
            out.append({"id": m[1], "name": text(el)})
    return out


def periods(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    out, seen = [], set()
    for el in soup.select("[onclick*='menuListSelectMenu']"):
        m = MENU_RE.search(el.get("onclick", ""))
        if m and m[1] not in seen:
            seen.add(m[1])
            header = el.find_previous(class_="card-title") or el.find_previous("header")
            out.append({"id": m[1], "name": text(el), "dateText": text(header)})
    return out


def categories(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    out, current = [], None
    for row in soup.select("tr.cbo_nn_itemGroupRow, tr[data-categoryid]"):
        if "cbo_nn_itemGroupRow" in row.get("class", []):
            m = CATEGORY_RE.search(row.get("onclick", ""))
            current = {"categoryId": m[1] if m else None,
                       "name": text(row.select_one("td div")) or text(row), "items": []}
            out.append(current)
            continue
        link = row.select_one("a[onclick*='getItemNutritionLabelOnClick']")
        button = row.select_one("button[data-detailoid]")
        m = DETAIL_RE.search(link.get("onclick", "")) if link else None
        detail = (button.get("data-detailoid") if button else None) or (m[1] if m else None)
        if not detail:
            continue
        if current is None:
            current = {"categoryId": None, "name": "Other", "items": []}
            out.append(current)
        cells = row.find_all("td", recursive=False)
        name = text(link) if link else (text(cells[0]) if cells else "")
        if not name and cells:
            name = text(cells[0])
        # Icon tooltips may contain dietary flags as well as allergens.
        icons = [img.get("title") for img in (link.select("img[title]") if link else []) if img.get("title")]
        current["items"].append({
            "id": str(detail), "name": name,
            "serving": text(cells[2]) if len(cells) >= 3 else "",
            "reportedIcons": icons,
        })
    return out


def parse_label(html: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    if soup.select_one("#errorPanel, .cbo_nn_PanelErrorDiv"):
        raise RuntimeError("CBORD returned an error panel, not nutrition information")
    label = soup.select_one("#nutritionLabel") or soup
    # Preserve exact visible label text; numeric normalisation can be expanded
    # after live validation against the UK nutrition format.
    return {
        "labelText": text(label),
        "ingredients": text(label.select_one(".cbo_nn_LabelIngredients")),
        "contains": text(label.select_one(".cbo_nn_LabelAllergens")),
    }


class HttpClient:
    name = "http"
    def __init__(self, base: str = BASE):
        self.base = base.rstrip("/")
        self.s = requests.Session()
        self.s.headers.update({"User-Agent": UA, "X-Requested-With": "XMLHttpRequest",
                               "Referer": self.base})

    def landing(self) -> str:
        # Preserve any ASP.NET session cookie established by the response.
        r = self.s.get(self.base, timeout=TIMEOUT)
        r.raise_for_status()
        if "html" not in r.headers.get("Content-Type", "text/html").lower():
            raise RuntimeError("Landing page did not return HTML")
        return r.text

    def post(self, path: str, data: dict, *, is_json: bool = True) -> Any:
        time.sleep(CALL_DELAY)
        r = self.s.post(f"{self.base}/{path}", data=data, timeout=TIMEOUT,
                        headers={"Accept": "application/json, text/javascript, */*; q=0.01"})
        r.raise_for_status()
        if not is_json:
            return r.text
        try:
            value = r.json()
        except ValueError as exc:
            raise RuntimeError(f"{path}: expected JSON, got {r.headers.get('Content-Type')}; "
                               f"body begins {r.text[:120]!r}") from exc
        if not isinstance(value, dict) or not value.get("success") or not isinstance(value.get("panels"), list):
            raise RuntimeError(f"{path}: CBORD did not return successful panels: {str(value)[:160]}")
        return value

    def close(self):
        self.s.close()


class BrowserClient:
    name = "chromium"
    def __init__(self, base: str = BASE):
        from playwright.sync_api import sync_playwright
        self.base = base.rstrip("/")
        self.p = sync_playwright().start()
        self.browser = self.p.chromium.launch(headless=True)
        self.context = self.browser.new_context(user_agent=UA)
        self.page = self.context.new_page()
        self.page.set_default_timeout(TIMEOUT * 1000)

    def landing(self) -> str:
        self.page.goto(self.base, wait_until="domcontentloaded", timeout=TIMEOUT * 1000)
        self.page.wait_for_timeout(1600)
        return self.page.content()

    def post(self, path: str, data: dict, *, is_json: bool = True) -> Any:
        time.sleep(CALL_DELAY)
        result = self.page.evaluate("""async ({path, data, isJson}) => {
            const body = new URLSearchParams(data);
            const response = await fetch(location.pathname.replace(/\\/$/, '') + '/' + path, {
                method: 'POST', credentials: 'same-origin',
                headers: {'X-Requested-With':'XMLHttpRequest',
                          'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
                body
            });
            const txt = await response.text();
            if (!response.ok) throw new Error(path + ': HTTP ' + response.status + ': ' + txt.slice(0,140));
            if (!isJson) return txt;
            try {return JSON.parse(txt)}
            catch(e) {throw new Error(path + ': returned non-JSON: ' + txt.slice(0,140))}
        }""", {"path": path, "data": data, "isJson": is_json})
        if is_json and (not isinstance(result, dict) or not result.get("success") or
                        not isinstance(result.get("panels"), list)):
            raise RuntimeError(f"{path}: invalid panels: {str(result)[:160]}")
        return result

    def close(self):
        self.browser.close()
        self.p.stop()


def panel(payload: dict, panel_id: str) -> str:
    return next((p.get("html", "") for p in payload.get("panels", [])
                 if p.get("id") == panel_id), "")


def collect(client: Any, *, include_labels: bool, max_labels: int,
            max_menus: int, only_venues: str = "") -> dict:
    html = client.landing()
    all_units = units(html)
    if not all_units:
        raise RuntimeError("No unit links found in landing HTML. This UK installation may use a different layout.")
    chosen = [u for u in all_units if not only_venues or only_venues.lower() in u["name"].lower()]
    if not chosen:
        raise RuntimeError(f"No venue matches filter {only_venues!r}")

    report = {
        "source": client.base,
        "capturedAtUTC": datetime.now(timezone.utc).isoformat(),
        "transport": client.name,
        "note": "Informational snapshot only. Never use as the sole basis for an allergen safety decision.",
        "includesLabels": include_labels,
        "venues": [], "errors": []
    }
    count_menus, count_items, count_labels, label_errors, label_attempts = 0, 0, 0, 0, 0
    for u in chosen:
        venue = {"id": u["id"], "name": u["name"], "menus": []}
        report["venues"].append(venue)
        print(f"  {u['name']}", flush=True)
        try:
            response = client.post("Unit/SelectUnitFromUnitsList", {"unitOid": u["id"]})
            all_periods = periods(panel(response, "menuPanel"))
            if not all_periods:
                all_periods = [{"id": None, "name": "Current items", "dateText": ""}]
            for period in all_periods:
                if count_menus >= max_menus:
                    report["errors"].append("Maximum menu limit reached; report may be incomplete")
                    break
                try:
                    if period["id"]:
                        selected = client.post("Menu/SelectMenu", {"menuOid": period["id"]})
                        item_html = panel(selected, "itemPanel")
                    else:
                        item_html = panel(response, "itemPanel")
                    cats = categories(item_html)
                    entry = {"id": period["id"], "name": period["name"],
                             "dateText": period["dateText"], "categories": cats}
                    venue["menus"].append(entry)
                    count_menus += 1
                    count_items += sum(len(c["items"]) for c in cats)
                    if include_labels and label_attempts < max_labels:
                        for category in cats:
                            for item in category["items"]:
                                if label_attempts >= max_labels:
                                    break
                                label_attempts += 1
                                try:
                                    value = client.post("NutritionDetail/ShowItemNutritionLabel",
                                                        {"detailOid": item["id"]}, is_json=False)
                                    item["label"] = parse_label(value)
                                    count_labels += 1
                                except Exception as exc:
                                    label_errors += 1
                                    item["labelError"] = str(exc)[:180]
                except Exception as exc:
                    report["errors"].append(f"{u['name']} / {period['name']}: {exc}")
        except Exception as exc:
            report["errors"].append(f"{u['name']}: {exc}")
        if count_menus >= max_menus:
            break
    report["stats"] = {"venuesFound": len(all_units), "venuesVisited": len(report["venues"]),
                       "menus": count_menus, "items": count_items, "labels": count_labels, "labelAttempts": label_attempts,
                       "labelErrors": label_errors, "errors": len(report["errors"])}
    if not count_items:
        raise RuntimeError("No menu items extracted; leaving last published successful export unchanged. " +
                           "; ".join(report["errors"][:4]))
    report["status"] = "partial" if report["errors"] or label_errors else "success"
    return report


def rows(report: dict) -> list[dict]:
    result = []
    for venue in report["venues"]:
        for menu in venue["menus"]:
            for cat in menu["categories"]:
                for item in cat["items"]:
                    label = item.get("label", {})
                    result.append({
                        "capturedAtUTC": report["capturedAtUTC"], "venue": venue["name"],
                        "date": menu["dateText"], "meal": menu["name"],
                        "category": cat["name"], "dish": item["name"],
                        "serving": item["serving"], "reportedIcons": "; ".join(item["reportedIcons"]),
                        "ingredients": label.get("ingredients", ""),
                        "contains": label.get("contains", ""),
                        "fullNutritionLabel": label.get("labelText", ""),
                    })
    return result


def save(report: dict, folder: Path) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    items = rows(report)
    (folder / "latest.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    with (folder / "latest.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["capturedAtUTC", "venue", "date", "meal",
                            "category", "dish", "serving", "reportedIcons", "ingredients",
                            "contains", "fullNutritionLabel"])
        writer.writeheader()
        writer.writerows(items)
    lines = ["# University of Reading – NetNutrition public menu snapshot", "",
             f"- Captured: {report['capturedAtUTC']}", f"- Status: {report['status']}",
             f"- Venues: {report['stats']['venuesVisited']}; menus: {report['stats']['menus']}; "
             f"items: {report['stats']['items']}",
             "- IMPORTANT: This snapshot is not authoritative allergen advice.", "",
             "| Venue | Date | Meal | Category | Dish | Listed dietary/allergen icons |",
             "|---|---|---|---|---|---|"]
    def md(s: Any) -> str:
        return str(s or "").replace("|", "\\|").replace("\n", " ").strip()
    for row in items:
        lines.append("| " + " | ".join(md(row[k]) for k in
                    ["venue", "date", "meal", "category", "dish", "reportedIcons"]) + " |")
    if report["errors"]:
        lines.extend(["", "## Extraction warnings", ""] + ["- " + md(e) for e in report["errors"]])
    (folder / "latest.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Saved {len(items)} menu items to {folder}")


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--transport", choices=["auto", "http", "browser"], default="auto")
    p.add_argument("--output", default="data")
    p.add_argument("--labels", action="store_true", help="Read public nutrition/ingredient label for individual dishes")
    p.add_argument("--max-labels", type=int, default=300)
    p.add_argument("--max-menus", type=int, default=160)
    p.add_argument("--venue", default="", help="Filter venue names by substring")
    args = p.parse_args(argv)
    client_modes = ["http", "browser"] if args.transport == "auto" else [args.transport]
    errors = []
    for mode in client_modes:
        client = None
        try:
            print(f"Trying {mode} reader against {BASE}", flush=True)
            client = HttpClient() if mode == "http" else BrowserClient()
            report = collect(client, include_labels=args.labels,
                             max_labels=args.max_labels, max_menus=args.max_menus,
                             only_venues=args.venue)
            save(report, Path(args.output))
            print(json.dumps(report["stats"], indent=2))
            return 0
        except Exception as exc:
            errors.append(f"{mode}: {type(exc).__name__}: {exc}")
            print("Reader unsuccessful: " + errors[-1], file=sys.stderr, flush=True)
        finally:
            if client is not None:
                client.close()
    raise SystemExit("Both access methods failed. Feed not overwritten.\n" + "\n".join(errors))


if __name__ == "__main__":
    sys.exit(main())
