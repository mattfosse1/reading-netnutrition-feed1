# University of Reading – Independent NetNutrition Reader (prototype)

A small **read-only** extractor for the public University of Reading NetNutrition site. It uses CBORD's *public-web-interface* session flow, not a privileged API, and never needs login credentials.

**Status: implemented and tested against simulated CBORD responses, but NOT live-validated against Reading**. The ChatGPT browsing environment receives a redirect loop from Reading's site, and the local build environment has no outbound DNS. This is why an independently hosted runner is the practical solution. If the UK instance is different from the documented CBORD format, the reader reports errors instead of inventing a menu.

## How it works

1. The runner retrieves the public NetNutrition home page, obtaining its anonymous session cookie.
2. It finds the location IDs, POSTs the public unit/menu selection requests in order, and extracts visible dish and dietary icon descriptions.
3. If normal HTTP requests fail, it retries using a real headless Chromium browser.
4. It writes `data/latest.json`, `data/latest.csv`, and `data/latest.md`. **It never writes an empty or fabricated successful export.**
5. The included GitHub Actions workflow can run automatically three times daily (UTC) and commit the new snapshots. If a run fails, the previous successful data stays in place.

### One-time activation on GitHub

1. Create a repository, preferably called `reading-netnutrition-feed`, in a GitHub account you control. It can be **public** if you want ChatGPT to read its snapshots without a connector. Do not publish private/nonpublic data there.
2. Upload the **contents** of this ZIP, including the `.github/workflows` folder, to the root of the repository.
3. In repository **Settings → Actions → General → Workflow permissions**, select **Read and write permissions** if GitHub's default policy doesn't permit the workflow to commit its output.
4. In **Actions → Refresh Reading public dining menus → Run workflow**, trigger the first run.
5. Check `data/latest.md` and the Actions log. If successful, share the repository URL with ChatGPT once. ChatGPT can attempt to read the resulting public Markdown/JSON whenever needed, even though its browser cannot navigate NetNutrition itself.

The public-readable file URLs will be:
- `https://github.com/YOUR_ACCOUNT/reading-netnutrition-feed/blob/main/data/latest.md`
- `https://raw.githubusercontent.com/YOUR_ACCOUNT/reading-netnutrition-feed/main/data/latest.json`

No feed exists at those URLs until **you have actually deployed and run** the repository. The script does **not** create a GitHub repository itself.

### Run manually

```bash
python -m pip install -r requirements.txt
python reader.py --transport http --output data
```

To include up to 300 public nutrition ingredient labels:

```bash
python reader.py --labels --max-labels 300
```

If direct HTTP fails, install Chromium and use `--transport auto`:

```bash
python -m playwright install chromium
python reader.py --transport auto --output data
```

The scheduled workflow currently collects dishes and icon tooltips only; you may change its run command to `python reader.py --transport auto --output data --labels --max-labels 300` for ingredient/nutrient detail. Full-label capture is slower and increases requests to the public service.

## Data considerations

- `reportedIcons` contains **all** icon tooltips and isn't automatically classified into the UK 14 regulated allergens. Labels are the stronger source for food analysis, but both are *snapshots* and should **not** be used for operational allergen decisions without official confirmation.
- The site may have multiple meal periods and date ranges. `dateText` is preserved exactly as displayed; it is not a machine-verified ISO date.
- Collection is throttled (`CALL_DELAY_SECONDS`, default 0.25s) and capped at 160 menus and 300 optional nutrition labels.
- No data are sent to a third-party API. If you make the repo public, the scraped public menu data become publicly readable on GitHub.
- This is an independent helper, not a CBORD-supported integration. Check your institution's policies before deploying automated collection.
- The documented endpoint structure originates from publicly available reverse-engineering for Duke University's CBORD NetNutrition, and might differ at Reading.

Sources documenting CBORD public-web endpoints:
- https://github.com/RW290/Duke-Net-Nutrition
- https://www.michael-lei.com/projects/duke-dine
