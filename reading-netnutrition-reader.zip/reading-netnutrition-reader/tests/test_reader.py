import tempfile
import unittest
from pathlib import Path
from reader import units, periods, categories, parse_label, collect, save

LANDING = '''<a onclick="unitsSelectUnit(12)">Park Eat</a><a onclick="unitsSelectUnit(13)">Wantage Hall</a>'''
PERIODS = '''<div class="card-title">Monday 23 November</div><a onclick="menuListSelectMenu(40)">Lunch</a>'''
ITEMS = '''<table>
<tr class="cbo_nn_itemGroupRow" onclick="toggleCourseItems(this, 51)"><td><div>Hot mains</div></td></tr>
<tr data-categoryid="51"><td><a onclick="getItemNutritionLabelOnClick(event, 223)"><img title="Contains Milk"/>Roasted Vegetable Lasagne</a></td><td></td><td>200g</td></tr>
</table>'''
LABEL = '''<div id="nutritionLabel"><div class="cbo_nn_LabelIngredients">Ingredients: pasta, tomato</div><div class="cbo_nn_LabelAllergens">Contains milk</div>345 kcal</div>'''

class MockClient:
    name = 'test'
    base = 'https://example.invalid'
    def landing(self): return LANDING
    def post(self, path, data, *, is_json=True):
        if not is_json: return LABEL
        if path.startswith('Unit'):
            if data['unitOid'] == '13':
                return {'success': True, 'panels': [{'id':'itemPanel','html':ITEMS}]}
            return {'success': True, 'panels': [{'id':'menuPanel','html':PERIODS}]}
        if path.startswith('Menu'):
            return {'success': True, 'panels': [{'id':'itemPanel','html':ITEMS}]}
        raise AssertionError(path)

class Tests(unittest.TestCase):
    def test_units(self):
        self.assertEqual([u['name'] for u in units(LANDING)], ['Park Eat', 'Wantage Hall'])
    def test_periods(self):
        self.assertEqual(periods(PERIODS)[0]['name'], 'Lunch')
    def test_categories(self):
        item = categories(ITEMS)[0]['items'][0]
        self.assertEqual(item['name'], 'Roasted Vegetable Lasagne')
        self.assertEqual(item['reportedIcons'], ['Contains Milk'])
    def test_label(self):
        self.assertIn('pasta', parse_label(LABEL)['ingredients'])
    def test_end_to_end(self):
        report = collect(MockClient(), include_labels=True, max_labels=2, max_menus=4)
        self.assertEqual(report['stats']['menus'], 2)
        self.assertEqual(report['stats']['items'], 2)
        self.assertEqual(report['stats']['labels'], 2)
        with tempfile.TemporaryDirectory() as td:
            save(report, Path(td))
            for filename in ['latest.json', 'latest.csv', 'latest.md']:
                self.assertTrue((Path(td) / filename).is_file())
    def test_does_not_succeed_empty(self):
        class Empty(MockClient):
            def landing(self): return '<p>nothing</p>'
        with self.assertRaises(RuntimeError):
            collect(Empty(), include_labels=False, max_labels=0, max_menus=2)

if __name__ == '__main__': unittest.main()
